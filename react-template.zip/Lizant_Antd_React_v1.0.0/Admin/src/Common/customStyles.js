import { customStyle } from "../config";// Adjust the import path to match your project structure
function usecustomStyles() {
  return customStyle.token;
}
export default usecustomStyles; 