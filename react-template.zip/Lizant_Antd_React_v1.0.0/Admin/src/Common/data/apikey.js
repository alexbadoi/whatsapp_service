const apiData = [
    { id: 1, name: "StreamArt", createdBy: "Tara Hawkins", apiKey: "9e6d336a-2f98-43e9-9fa6-11b4d5cdaf62", status: "Disable", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 2, name: "StreamArt", createdBy: "Nicki Butler", apiKey: "8abba6e5-9622-46d2-8c52-c937e1d20ba2", status: "Active", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 3, name: "StreamArt", createdBy: "Addison Black", apiKey: "aecc1ede-f613-48d5-8140-7108b324f0bd", status: "Active", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 4, name: "StreamArt", createdBy: "Harley Watkins", apiKey: "84540348-f97d-41de-87c6-f5eae32aecc5", status: "Disable", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 5, name: "StreamArt", createdBy: "Cassian Jenning", apiKey: "33ec3a35-8b44-48f3-ba68-f3ea1e9ef214", status: "Active", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 6, name: "StreamArt", createdBy: "Elizabeth Allen", apiKey: "b69ee258-1053-4e08-adbd-d37837f9c558", status: "Active", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 7, name: "StreamArt", createdBy: "Philippa Santiago", apiKey: "0b53e8e2-e53d-4067-8be0-9cddea19e45e", status: "Active", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 8, name: "StreamArt", createdBy: "Zynthia Marrow", apiKey: "ed4c0d11-7d49-4c94-aae8-83fafb226ee9", status: "Active", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
    { id: 9, name: "StreamArt", createdBy: "Michael Morris", apiKey: "fef67078-6fb6-4689-b342-6ddc24481728", status: "Disable", createDate: "24 Sep 2022", expirydate: "24 Jan 2023" },
]

export { apiData } ;