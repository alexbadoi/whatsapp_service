const dataBasicBar = [
    {
        year: '1951 Year',
        value: 38,
    },
    {
        year: '1952 Year',
        value: 52,
    },
    {
        year: '1956 Year',
        value: 61,
    },
    {
        year: '1957 Year',
        value: 145,
    },
    {
        year: '1958 Year',
        value: 48,
    },
];

const dataCustomizeColor = [
    {
        type: 'Appliances',
        sales: 38,
    },
    {
        type: 'Grain & oil',
        sales: 52,
    },
    {
        type: 'fresh fruit',
        sales: 61,
    },
    {
        type: 'Beauty care',
        sales: 145,
    },
    {
        type: 'Baby Products',
        sales: 48,
    },
    {
        type: 'imported food',
        sales: 38,
    },
    {
        type: 'food & drink',
        sales: 38,
    },
    {
        type: 'household',
        sales: 38,
    },
];

// const dataSpecifybar = [
//     {
//         type: 'Appliances',
//         sales: 38,
//     },
//     {
//         type: 'Grain & oil',
//         sales: 52,
//     },
//     {
//         type: '生鲜水果',
//         sales: 61,
//     },
//     {
//         type: '美容洗护',
//         sales: 145,
//     },
//     {
//         type: '母婴用品',
//         sales: 48,
//     },
//     {
//         type: '进口食品',
//         sales: 38,
//     },
//     {
//         type: '食品饮料',
//         sales: 38,
//     },
//     {
//         type: '家庭清洁',
//         sales: 38,
//     },
// ];

export { dataBasicBar, dataCustomizeColor }