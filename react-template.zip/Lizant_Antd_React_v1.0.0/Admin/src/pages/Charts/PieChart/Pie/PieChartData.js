const datapiechart = [
    {
        type: 'Category one',
        value: 27,
    },
    {
        type: 'Category two',
        value: 25,
    },
    {
        type: 'Category three',
        value: 18,
    },
    {
        type: 'Category four',
        value: 15,
    },
    {
        type: 'Category five',
        value: 10,
    },
    {
        type: 'other',
        value: 5,
    },
];

const dataPersonalizedLabel = [
    {
        type: 'Category one',
        value: 100,
    },
    {
        type: 'Category two',
        value: 200,
    },
    {
        type: 'Category three',
        value: 300,
    },
    {
        type: 'Category four',
        value: 100,
    },
    {
        type: 'Category five',
        value: 100,
    },
    {
        type: 'other',
        value: 200,
    },
];

const datatexturedpie = [
    {
        zender: 'male',
        sold: 0.45,
    },
    {
        zender: 'female',
        sold: 0.55,
    },
];

export { datapiechart, dataPersonalizedLabel, datatexturedpie }